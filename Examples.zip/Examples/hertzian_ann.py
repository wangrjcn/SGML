import SGML
import torch

seed_value = 0
torch.manual_seed(seed_value)

solution_1 = SGML.create_solution_function(expression='((9 * F ** 2 / d1) * \
((1 - 0.3 ** 2) / (210 * 10 ** 9)) ** 2) ** (1/3)',
                                           variables=['F', 'd1'])
solution_2 = SGML.create_solution_function(expression='((9 * F ** 2 / d2) * \
((1 - 0.3 ** 2) / (210 * 10 ** 9)) ** 2) ** (1/3)',
                                           variables=['F', 'd2'])
# %%
my_ann = SGML.ann(train_path='./Examples/dataset/hertzian_train1.csv',
                  test_path='./Examples/dataset/hertzian_test1.csv',
                  feature_names=['F', 'd1', 'd2'],
                  label_names=['y'],
                  # solution_functions=[solution_1, solution_2],
                  solution_functions='default',
                  model_loadpath='default',
                  model_savepath='default',
                  hidden_layers='default',
                  activation_function='default',
                  batch_size='default',
                  criterion='default',
                  optimizer='default',
                  learning_rate='default',
                  epochs='default')

my_ann.train()

y_test = my_ann.test()
y_pre = my_ann.predict()

my_ann.plot_results(y_test, y_pre)
