import pandas as pd
import numpy as np
from torch.utils.data import DataLoader, TensorDataset
import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt


def ann(train_path,
        test_path,
        feature_names,
        lable_names,
        hidden_layers=None,
        epochs=None,
        solution_functions=None,
        batch_size=None,
        activation_function=None,
        model_loadpath=None,
        model_savepath=None,
        criterion=None,
        optimizer=None,
        learning_rate=None):
    # Loading data
    train_data = pd.read_csv(train_path)
    test_data = pd.read_csv(test_path)

    train_features = train_data[feature_names].astype(float)
    train_labels = train_data[lable_names].astype(float)

    test_features = test_data[feature_names].astype(float)
    test_labels = test_data[lable_names].astype(float)

    # Generate "solutions" columns based on user-defined solution functions
    if solution_functions is not None:
        for i, solution in enumerate(solution_functions):
            train_features[f'solutions_{i}'] = solution(train_features)
            test_features[f'solutions_{i}'] = solution(test_features)

    # Standardize features
    # scaler = MinMaxScaler()
    # train_features = pd.DataFrame(scaler.fit_transform(train_features), columns=train_features.columns)
    # test_features = pd.DataFrame(scaler.transform(test_features), columns=test_features.columns)
    train_features_max = train_features.max()
    train_features = train_features / train_features_max
    test_features = test_features / train_features_max

    train_labels_max = train_labels.max()
    train_labels = train_labels / train_labels_max

    # Create TensorDatasets
    train_data = TensorDataset(torch.Tensor(train_features.values), torch.Tensor(train_labels.values))
    test_data = TensorDataset(torch.Tensor(test_features.values), torch.Tensor(test_labels.values))

    # Create DataLoaders
    if batch_size is None:
        batch_size = train_features.shape[0]
    else:
        batch_size = batch_size

    train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_data, batch_size=batch_size, shuffle=False)

    # Define neural network architecture
    class nn_arch(nn.Module):
        def __init__(self, feature_num=train_features.shape[1], hidden_layers=hidden_layers, label_num=train_labels.shape[1], activation_function=activation_function):
            super(nn_arch, self).__init__()

            self.layers = nn.ModuleList()

            if activation_function is None:
                self.activation_function = nn.PReLU()
            else:
                self.activation_function = activation_function

            if hidden_layers is None:
                hidden_layers = [8, 8]
            else:
                hidden_layers = hidden_layers

            self.layers.append(nn.Linear(feature_num, hidden_layers[0]))

            for i in range(1, len(hidden_layers)):
                self.layers.append(self.activation_function)
                self.layers.append(nn.Linear(hidden_layers[i - 1], hidden_layers[i]))

            self.layers.append(nn.Linear(hidden_layers[-1], label_num))

        def forward(self, x):
            for layer in self.layers:
                x = layer(x)
            return x

    nn_beta = nn_arch()

    if model_loadpath is None:
        # define loss function
        if criterion is None:
            criterion = nn.MSELoss()
        else:
            criterion = criterion

        # define learning rate
        if learning_rate is None:
            learning_rate = 0.01
        else:
            learning_rate = learning_rate

        if optimizer is None:
            optimizer = optim.Adam(nn_beta.parameters(), lr=learning_rate)
        else:
            optimizer = optimizer

        if epochs is None:
            epochs = 5000
        else:
            epochs = epochs

        with tqdm(total=epochs, desc='Training Progress', unit='epoch') as epoch_pbar:
            for epoch in range(epochs):
                total_loss = 0
                for inputs_train, labels_train in train_loader:
                    optimizer.zero_grad()
                    outputs = nn_beta(inputs_train)
                    loss = criterion(outputs, labels_train.reshape(-1, 1))
                    loss.backward()
                    optimizer.step()
                    total_loss += loss.item()

                # update the bar
                avg_loss = total_loss / len(train_loader)
                epoch_pbar.set_postfix(loss=avg_loss, refresh=True)
                epoch_pbar.update(1)

        if model_savepath is not None:
            torch.save(nn_beta.state_dict(), model_savepath)
    else:
        state_dict = torch.load(model_loadpath)
        nn_beta.load_state_dict(state_dict)

    # predict
    all_predictions = []
    all_tests = []
    for inputs_test, labels_test in test_loader:
        predictions = nn_beta(inputs_test)
        all_predictions.append(predictions.detach().numpy())
        all_tests.append(labels_test.detach().numpy())

    y_test = np.concatenate(all_tests, axis=0).reshape(-1, 1)
    y_pre = np.concatenate(all_predictions, axis=0) * (np.array(train_labels_max))

    # prediction-test relationship
    plt.rcParams['xtick.direction'] = 'in'
    plt.rcParams['ytick.direction'] = 'in'
    plt.figure(figsize=(4, 3))
    plt.rc('font', family='Times New Roman', size=12)
    plt.subplots_adjust(left=0.16, bottom=0.16, top=0.95, right=0.95)
    plt.plot(y_test, y_test, linewidth=1, color='grey', alpha=0.7, zorder=1)
    plt.scatter(y_test, y_pre, s=0.5, color='lightcoral', alpha=1, zorder=2)
    plt.xlabel("Test")
    plt.ylabel("Prediction")
    plt.show()

    return nn_beta, y_test, y_pre
