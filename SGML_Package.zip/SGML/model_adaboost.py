import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
from sklearn.ensemble import AdaBoostRegressor
from sklearn.linear_model import LinearRegression
from joblib import dump, load


def adaboost(train_path,
             test_path,
             feature_names,
             lable_names,
             solution_functions='default',
             model_loadpath='default',
             model_savepath='default',
             estimator='default',
             n_estimators='default',
             learning_rate='default',
             loss='default',
             random_state='default'):

    if estimator == 'default':
        estimator = LinearRegression()
    else:
        estimator = estimator

    if n_estimators == 'default':
        n_estimators = 50
    else:
        n_estimators = n_estimators

    if learning_rate == 'default':
        learning_rate = 1.0
    else:
        learning_rate = learning_rate

    if loss == 'default':
        loss = 'linear'
    else:
        loss = loss

    # Loading data
    train_data = pd.read_csv(train_path)
    test_data = pd.read_csv(test_path)

    train_features = train_data[feature_names].astype(float)
    train_labels = train_data[lable_names].astype(float)

    test_features = test_data[feature_names].astype(float)
    test_labels = test_data[lable_names].astype(float)

    # Generate "solutions" columns based on user-defined solution functions
    if solution_functions != 'default':
        for i, solution in enumerate(solution_functions):
            train_features[f'solutions_{i}'] = solution(train_features)
            test_features[f'solutions_{i}'] = solution(test_features)

    # Standardize features
    # scaler = MinMaxScaler()
    # train_features = pd.DataFrame(scaler.fit_transform(train_features), columns=train_features.columns)
    # test_features = pd.DataFrame(scaler.transform(test_features), columns=test_features.columns)
    train_features_max = train_features.max()
    train_features = np.array(train_features / train_features_max)
    test_features = np.array(test_features / train_features_max)

    train_labels = np.array(train_labels).ravel()
    test_labels = np.array(test_labels).ravel()

    # load or creat model
    if model_loadpath == 'default':

        # creat ridge regression model
        model_AB = AdaBoostRegressor(estimator=estimator,
                                     n_estimators=n_estimators,
                                     learning_rate=learning_rate,
                                     loss=loss,
                                     random_state=random_state)

        # fitting
        model_AB.fit(train_features, train_labels)

        # save model
        if model_savepath != 'default':
            save_path = model_savepath
            dump(model_AB, save_path)
    else:
        model_AB = load(model_loadpath)

    # predict
    y_pre = model_AB.predict(test_features)
    y_pre = y_pre.reshape(-1, 1)
    y_test = test_labels.reshape(-1, 1)

    # prediction-test relationship
    plt.rcParams['xtick.direction'] = 'in'
    plt.rcParams['ytick.direction'] = 'in'
    plt.figure(figsize=(4, 3))
    plt.rc('font', family='Times New Roman', size=12)
    plt.subplots_adjust(left=0.16, bottom=0.16, top=0.95, right=0.95)
    plt.plot(y_test, y_test, linewidth=1, color='grey', alpha=0.7, zorder=1)
    plt.scatter(y_test, y_pre, s=0.5, color='lightcoral', alpha=1, zorder=2)
    plt.xlabel("Test")
    plt.ylabel("Prediction")
    plt.show()

    return model_AB, y_test, y_pre
