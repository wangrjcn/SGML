import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
from sklearn.linear_model import BayesianRidge
from joblib import dump, load


def bayesianridge(train_path,
                  test_path,
                  feature_names,
                  lable_names,
                  solution_functions='default',
                  model_loadpath='default',
                  model_savepath='default',
                  max_iter='default',
                  tol='default',
                  alpha_1='default',
                  alpha_2='default',
                  lambda_1='default',
                  lambda_2='default',
                  alpha_init='default',
                  lambda_init='default',
                  compute_score='default',
                  fit_intercept='default',
                  copy_X='default',
                  verbose='default'):
    if tol == 'default':
        tol = 0.001
    else:
        tol = tol

    if alpha_1 == 'default':
        alpha_1 = 1e-06
    else:
        alpha_1 = alpha_1

    if alpha_2 == 'default':
        alpha_2 = 1e-06
    else:
        alpha_2 = alpha_2

    if lambda_1 == 'default':
        lambda_1 = 1e-06
    else:
        lambda_1 = lambda_1

    if lambda_2 == 'default':
        lambda_2 = 1e-06
    else:
        lambda_2 = lambda_2

    if compute_score == 'default':
        compute_score = False
    else:
        compute_score = compute_score

    if fit_intercept == 'default':
        fit_intercept = True
    else:
        fit_intercept = fit_intercept

    if copy_X == 'default':
        copy_X = True
    else:
        copy_X = copy_X

    if verbose == 'default':
        verbose = False
    else:
        verbose = verbose

    # Loading data
    train_data = pd.read_csv(train_path)
    test_data = pd.read_csv(test_path)

    train_features = train_data[feature_names].astype(float)
    train_labels = train_data[lable_names].astype(float)

    test_features = test_data[feature_names].astype(float)
    test_labels = test_data[lable_names].astype(float)

    # Generate "solutions" columns based on user-defined solution functions
    if solution_functions != 'default':
        for i, solution in enumerate(solution_functions):
            train_features[f'solutions_{i}'] = solution(train_features)
            test_features[f'solutions_{i}'] = solution(test_features)

    # Standardize features
    # scaler = MinMaxScaler()
    # train_features = pd.DataFrame(scaler.fit_transform(train_features), columns=train_features.columns)
    # test_features = pd.DataFrame(scaler.transform(test_features), columns=test_features.columns)
    train_features_max = train_features.max()
    train_features = np.array(train_features / train_features_max)
    test_features = np.array(test_features / train_features_max)

    train_labels = np.array(train_labels).ravel()
    test_labels = np.array(test_labels).ravel()

    # load or creat model
    if model_loadpath == 'default':

        # creat ridge regression model
        model_BR = BayesianRidge(max_iter=max_iter,
                                 tol=tol,
                                 alpha_1=alpha_1,
                                 alpha_2=alpha_2,
                                 lambda_1=lambda_1,
                                 lambda_2=lambda_2,
                                 alpha_init=alpha_init,
                                 lambda_init=lambda_init,
                                 compute_score=compute_score,
                                 fit_intercept=fit_intercept,
                                 copy_X=copy_X,
                                 verbose=verbose)

        # fitting
        model_BR.fit(train_features, train_labels)

        # save model
        if model_savepath != 'default':
            save_path = model_savepath
            dump(model_BR, save_path)
    else:
        model_BR = load(model_loadpath)

    # predict
    y_pre = model_BR.predict(test_features)
    y_pre = y_pre.reshape(-1, 1)
    y_test = test_labels.reshape(-1, 1)

    # prediction-test relationship
    plt.rcParams['xtick.direction'] = 'in'
    plt.rcParams['ytick.direction'] = 'in'
    plt.figure(figsize=(4, 3))
    plt.rc('font', family='Times New Roman', size=12)
    plt.subplots_adjust(left=0.16, bottom=0.16, top=0.95, right=0.95)
    plt.plot(y_test, y_test, linewidth=1, color='grey', alpha=0.7, zorder=1)
    plt.scatter(y_test, y_pre, s=0.5, color='lightcoral', alpha=1, zorder=2)
    plt.xlabel("Test")
    plt.ylabel("Prediction")
    plt.show()

    return model_BR, y_test, y_pre
